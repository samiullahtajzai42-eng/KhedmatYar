package com.example.khedmatyar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

data class Service(val title: String, val description: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KhedmatYarApp() }
    }
}

@Composable
fun KhedmatYarApp() {
    val services = listOf(
        Service("تعمیرات موبایل", "تعمیر و خدمات موبایل"),
        Service("برق‌کاری", "خدمات برق ساختمان"),
        Service("لوله‌کشی", "تعمیر و نصب لوله"),
        Service("نظافت", "خدمات نظافت منزل و محل کار")
    )

    MaterialTheme {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text("خدمت‌یار") }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
            ) {
                Text(
                    "خدمات مورد نیازت را پیدا کن",
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right
                )

                Spacer(Modifier.height(16.dp))

                Button(
                    onClick = {},
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("ثبت درخواست خدمت")
                }

                Spacer(Modifier.height(20.dp))

                Text(
                    "خدمات موجود",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right
                )

                Spacer(Modifier.height(8.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(services) { service ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.End
                            ) {
                                Text(
                                    service.title,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(service.description)
                                Spacer(Modifier.height(8.dp))
                                OutlinedButton(onClick = {}) {
                                    Text("مشاهده")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
